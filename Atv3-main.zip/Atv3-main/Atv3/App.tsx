import Home from "./screens/Home";


export default function App() {
  return (
    <Home/>
  );
}


