import { Text, TouchableOpacity, View } from "react-native";
import { styles } from "./styles";
import { useState } from "react";

export default function Home() {
  const [valN, setValN] = useState(0);
  const [valE, setValE] = useState(0);

  function handleAddN() {
    setValN(valN + 1);
  }

  function handleAddE() {
    setValE(valE + 1);
  }

  function handleRemoveN() {
    setValN(valN - 1);
  }
  function handleRemoveE() {
    setValE(valE - 1);
  }

  function handleZerar() {
    setValE(0);
    setValN(0);
  }
  return (
    <View style={styles.container}>
      <Text style={styles.tittle}>Marcador de Truco</Text>
      <View style={styles.container2}>
        <Text style={styles.text}>Nós</Text>
        <Text style={styles.text2}>Eles</Text>
      </View>
      <View style={styles.container3}>
        <Text style={styles.num}>{valN}</Text>
        <Text style={styles.num2}>{valE}</Text>
      </View>
      <View style={styles.container4}>
        <TouchableOpacity style={styles.button} onPress={handleAddN}>
          <Text style={styles.textButton}>+1</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={handleAddE}>
          <Text style={styles.textButton}>+1</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.container5}>
        <TouchableOpacity style={styles.button2} onPress={handleRemoveN}>
          <Text style={styles.textButton}>-1</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button2} onPress={handleRemoveE}>
          <Text style={styles.textButton}>-1</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.container6}>
        <TouchableOpacity style={styles.button3} onPress={handleZerar}>
          <Text style={styles.textButton}>Zerar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
