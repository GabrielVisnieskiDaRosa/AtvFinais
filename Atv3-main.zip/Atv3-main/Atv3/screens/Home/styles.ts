import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#383535",
  },
  tittle: {
    color: "#FFF",
    fontSize: 35,
    paddingLeft: 75,
    paddingTop: 30,
  },
  container2: {
    height: 110,
    flexDirection: "row",
  },
  container3: {
    height: 140,
    flexDirection: "row",
  },
  container4: {
    height: 80,
    flexDirection: "row",
  },
  container5: {
    height: 100,
    flexDirection: "row",
  },
  container6: {
    flex: 1
  },
  text: {
    paddingTop: 60,
    paddingLeft: 70,
    color: "#4AA5F9",
    fontSize: 50,
  },
  text2: {
    paddingTop: 60,
    paddingLeft: 100,
    fontSize: 50,
    color: "#C08DF3",
  },
  num: {
    paddingLeft: 70,
    color: "#4AA5F9",
    fontSize: 150,
  },
  num2: {
    paddingLeft: 115,
    fontSize: 150,
    color: "#C08DF3",
  },
  button: {
    backgroundColor: "#589D52",
    marginLeft: 50,
    width: 120,
    height:64,
    borderRadius: 5,
  },
  textButton:{
    color:"#FFF",
    fontSize: 55,
    textAlign: "center"
  },
  button2: {
    backgroundColor: "#BD1010",
    marginLeft: 50,
    width: 120,
    height:64,
    borderRadius: 5,
  },
  button3:{
    backgroundColor:"#DE9609",
    width:290,
    margin:5,
    borderRadius: 5,
    marginLeft: 50
  }
});
